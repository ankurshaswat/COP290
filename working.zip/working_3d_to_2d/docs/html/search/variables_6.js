var searchData=
[
  ['is3d',['is3d',['../structVertice.html#ae1b4f2a0c6783f5cf06b6dbcc49f8231',1,'Vertice']]],
  ['isometricview',['isometricView',['../classUi__MainWindow.html#a762edccde6f2642394b92dcf163831ce',1,'Ui_MainWindow']]]
];
