var searchData=
[
  ['third',['third',['../structVertice.html#a781306a1aba368740f76928fc4b3b6bc',1,'Vertice']]],
  ['threed2_5f2d',['threeD2_2D',['../classUi__optionWindow.html#a5dcb7223009f3d24b4bec11b83102fff',1,'Ui_optionWindow']]],
  ['transform',['transform',['../helperfunctions_8cpp.html#a4a9bde2a0de0b0199de919d3b4628e89',1,'transform(Vertice v_in, double Xrot, double Yrot, double Zrot, double Xoff, double Yoff, double Zoff):&#160;helperfunctions.cpp'],['../helperfunctions_8h.html#a4a9bde2a0de0b0199de919d3b4628e89',1,'transform(Vertice v_in, double Xrot, double Yrot, double Zrot, double Xoff, double Yoff, double Zoff):&#160;helperfunctions.cpp']]],
  ['twod2_5f3d',['twoD2_3D',['../classUi__optionWindow.html#ae428e4702f07e7cfd83c2d3e992d89fd',1,'Ui_optionWindow']]]
];
