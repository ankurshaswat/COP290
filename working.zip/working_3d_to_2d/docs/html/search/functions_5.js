var searchData=
[
  ['loadobj',['loadOBJ',['../objLoader_8h.html#aceb7a3048c7f82ebf68f0256aedbe70f',1,'loadOBJ(const char *path):&#160;objLoader.cpp'],['../objLoader_8cpp.html#aceb7a3048c7f82ebf68f0256aedbe70f',1,'loadOBJ(const char *path):&#160;objLoader.cpp']]]
];
