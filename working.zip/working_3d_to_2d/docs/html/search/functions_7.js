var searchData=
[
  ['onplane',['onPlane',['../structPlane.html#a3a525d011cf5214cf9223976ce113876',1,'Plane']]],
  ['operator_2d',['operator-',['../structVertice.html#a2f9bd3f865f0613f41bbc2dd3ac2d08d',1,'Vertice']]],
  ['operator_3c',['operator&lt;',['../structVertice.html#a8ed5964130f1d72b0a9ab0ce72506e1d',1,'Vertice::operator&lt;()'],['../structEdge.html#acee00bfc0d6c9201c6def4c5c2b35058',1,'Edge::operator&lt;()']]],
  ['operator_3c_3c',['operator&lt;&lt;',['../basicComponents_8h.html#a6cdb990c0de2c272d0747713f4420f1c',1,'basicComponents.h']]],
  ['operator_3d_3d',['operator==',['../structVertice.html#a17d6154f69e230b4c927fe70e8442f4c',1,'Vertice::operator==()'],['../structEdge.html#ad7b8ac3b7836a7258252d348caf3d2a9',1,'Edge::operator==()']]],
  ['opposite_5fside',['opposite_side',['../hiddenLines_8h.html#a75204ad0589a339061889fd407aa38e2',1,'opposite_side(vector&lt; Vertice &gt; &amp;faceVertices, Vertice a, Vertice b):&#160;hiddenLines.cpp'],['../hiddenLines_8cpp.html#a836768e232c104dd933ab255f798d0d5',1,'opposite_side(vector&lt; Vertice &gt; &amp;faceVertices, Vertice e, Vertice f):&#160;hiddenLines.cpp']]],
  ['optionwindow',['optionWindow',['../classoptionWindow.html#a520eacaa5cabadee57621a9a24345302',1,'optionWindow']]]
];
