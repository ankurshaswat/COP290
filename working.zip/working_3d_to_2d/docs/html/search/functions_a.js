var searchData=
[
  ['readfile',['readFile',['../reconstMethods_8h.html#ab5b36acd93691246a5e348eecc9225cf',1,'readFile(const char *):&#160;reconstMethods.cpp'],['../reconstMethods_8cpp.html#a5b106c1c411ab1e9cbb880661e8702fc',1,'readFile(const char *path):&#160;reconstMethods.cpp']]],
  ['render',['render',['../renderMethods_8h.html#ab6043f874ec8d70f6af6449bbf1ab02a',1,'renderMethods.h']]],
  ['render2d',['render2D',['../renderMethods_8h.html#abbe049f22c313df9c0fe89db2a69f154',1,'render2D(Fig3D &amp;object3D, QPainter &amp;painter, int plane):&#160;renderMethods.cpp'],['../renderMethods_8cpp.html#abbe049f22c313df9c0fe89db2a69f154',1,'render2D(Fig3D &amp;object3D, QPainter &amp;painter, int plane):&#160;renderMethods.cpp']]],
  ['render2dhidden',['render2DHidden',['../hiddenLines_8h.html#aafdedb0fe0862c4196f86c1c1828d27f',1,'render2DHidden(Fig3D &amp;object3D, QPainter &amp;painter, int plane):&#160;hiddenLines.cpp'],['../hiddenLines_8cpp.html#aafdedb0fe0862c4196f86c1c1828d27f',1,'render2DHidden(Fig3D &amp;object3D, QPainter &amp;painter, int plane):&#160;hiddenLines.cpp']]],
  ['render2dinlabel',['render2DinLabel',['../classMainWindow.html#abfa616ee6054f649786c044555289380',1,'MainWindow']]],
  ['render2dto3d',['render2Dto3D',['../classMainWindow.html#a91288f71f3b29443c1243ddb653f3898',1,'MainWindow']]],
  ['renderallviews',['renderAllViews',['../classMainWindow.html#a8c1191ba31eb843bede258cd5fdc571e',1,'MainWindow']]],
  ['renderaxes',['renderAxes',['../renderMethods_8h.html#af446c170783ff0c5ebee6ce16c8f65d6',1,'renderAxes(Fig3D &amp;object3D, QPainter &amp;painter, int plane):&#160;renderMethods.cpp'],['../renderMethods_8cpp.html#af446c170783ff0c5ebee6ce16c8f65d6',1,'renderAxes(Fig3D &amp;object3D, QPainter &amp;painter, int plane):&#160;renderMethods.cpp']]],
  ['renderfromedges',['renderFromEdges',['../classMainWindow.html#a3309de2dae8bbfaf0ff645fe372aa644',1,'MainWindow']]],
  ['retranslateui',['retranslateUi',['../classUi__MainWindow.html#a097dd160c3534a204904cb374412c618',1,'Ui_MainWindow::retranslateUi()'],['../classUi__optionWindow.html#a0904702fea102a0a8e79bf8efd00d6ec',1,'Ui_optionWindow::retranslateUi()']]]
];
