var searchData=
[
  ['setupui',['setupUi',['../classUi__MainWindow.html#acf4a0872c4c77d8f43a2ec66ed849b58',1,'Ui_MainWindow::setupUi()'],['../classUi__optionWindow.html#a37f3f54b7c4cde131daddc5433d4e37d',1,'Ui_optionWindow::setupUi()']]],
  ['setvertices',['setVertices',['../classMainWindow.html#ad61780253f03d8089d2e928a3113baf8',1,'MainWindow']]],
  ['setwireframe',['setWireFrame',['../classMainWindow.html#a9a9324e1f5908834f69b5a7944fcbc38',1,'MainWindow']]],
  ['setxrotation',['setXRotation',['../classMainWindow.html#a91ab701961139d21df1c4f8d7b31b870',1,'MainWindow']]],
  ['setyrotation',['setYRotation',['../classMainWindow.html#a023c99cfbdddc154e639d4d53b56a874',1,'MainWindow']]],
  ['setzrotation',['setZRotation',['../classMainWindow.html#a3069f073ff2ba99fd601f4f607e77f8b',1,'MainWindow']]]
];
