var searchData=
[
  ['incx',['incX',['../classMainWindow.html#a6ae88293630f79a3ccb75bc5e64daea5',1,'MainWindow']]],
  ['incy',['incY',['../classMainWindow.html#ad4fa62f605231f2c935f37f7a204bbf9',1,'MainWindow']]],
  ['incz',['incZ',['../classMainWindow.html#a25ae6019ab87c5e9bf844ac007b00249',1,'MainWindow']]],
  ['inf',['INF',['../helperfunctions_8cpp.html#a12c2040f25d8e3a7b9e1c2024c618cb6',1,'INF():&#160;helperfunctions.cpp'],['../hiddenLines_8cpp.html#a12c2040f25d8e3a7b9e1c2024c618cb6',1,'INF():&#160;hiddenLines.cpp']]],
  ['is3d',['is3d',['../structVertice.html#ae1b4f2a0c6783f5cf06b6dbcc49f8231',1,'Vertice']]],
  ['is_5finside',['is_inside',['../helperfunctions_8cpp.html#a948ecdee044f4ebf6f132257557292fc',1,'is_inside(Vertice v, set&lt; Edge &gt; edgeSet):&#160;helperfunctions.cpp'],['../helperfunctions_8h.html#a948ecdee044f4ebf6f132257557292fc',1,'is_inside(Vertice v, set&lt; Edge &gt; edgeSet):&#160;helperfunctions.cpp']]],
  ['iscontained',['isContained',['../classEdgeLoop.html#acae6f647805e3f043325f047208556c8',1,'EdgeLoop']]],
  ['isometricview',['isometricView',['../classUi__MainWindow.html#a762edccde6f2642394b92dcf163831ce',1,'Ui_MainWindow']]],
  ['issubset',['isSubset',['../helperfunctions_8cpp.html#ab52930079ad22c64677a4bcafd8728c7',1,'isSubset(vector&lt; int &gt; &amp;a, vector&lt; int &gt; &amp;b):&#160;helperfunctions.cpp'],['../helperfunctions_8h.html#ab52930079ad22c64677a4bcafd8728c7',1,'isSubset(vector&lt; int &gt; &amp;a, vector&lt; int &gt; &amp;b):&#160;helperfunctions.cpp']]]
];
