var searchData=
[
  ['faces',['faces',['../classFig3D.html#abd9f97ce3404190fd202b12885d56fe3',1,'Fig3D']]],
  ['first',['first',['../structVertice.html#a458c4138041414f66cc8234dcb8a76a8',1,'Vertice']]]
];
