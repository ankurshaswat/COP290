var searchData=
[
  ['vertices',['vertices',['../structEdge.html#adb182142702f93f85a3f41c86f4916ff',1,'Edge::vertices()'],['../classEdgeLoop.html#a781d9dd73f8b69c7b0075d4297f6b277',1,'EdgeLoop::vertices()'],['../classFig3D.html#a3d00aa545805c0c04563055cc183cbb9',1,'Fig3D::vertices()']]]
];
