var searchData=
[
  ['back_5fproj',['back_proj',['../hiddenLines_8h.html#a5245c9f2d3321def89057b7d397d84e3',1,'back_proj(Vertice v, Edge e, int plane):&#160;hiddenLines.cpp'],['../hiddenLines_8cpp.html#a5245c9f2d3321def89057b7d397d84e3',1,'back_proj(Vertice v, Edge e, int plane):&#160;hiddenLines.cpp']]]
];
