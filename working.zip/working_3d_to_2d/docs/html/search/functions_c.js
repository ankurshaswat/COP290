var searchData=
[
  ['transform',['transform',['../helperfunctions_8cpp.html#a4a9bde2a0de0b0199de919d3b4628e89',1,'transform(Vertice v_in, double Xrot, double Yrot, double Zrot, double Xoff, double Yoff, double Zoff):&#160;helperfunctions.cpp'],['../helperfunctions_8h.html#a4a9bde2a0de0b0199de919d3b4628e89',1,'transform(Vertice v_in, double Xrot, double Yrot, double Zrot, double Xoff, double Yoff, double Zoff):&#160;helperfunctions.cpp']]]
];
