var searchData=
[
  ['incx',['incX',['../classMainWindow.html#a6ae88293630f79a3ccb75bc5e64daea5',1,'MainWindow']]],
  ['incy',['incY',['../classMainWindow.html#ad4fa62f605231f2c935f37f7a204bbf9',1,'MainWindow']]],
  ['incz',['incZ',['../classMainWindow.html#a25ae6019ab87c5e9bf844ac007b00249',1,'MainWindow']]],
  ['is_5finside',['is_inside',['../helperfunctions_8cpp.html#a948ecdee044f4ebf6f132257557292fc',1,'is_inside(Vertice v, set&lt; Edge &gt; edgeSet):&#160;helperfunctions.cpp'],['../helperfunctions_8h.html#a948ecdee044f4ebf6f132257557292fc',1,'is_inside(Vertice v, set&lt; Edge &gt; edgeSet):&#160;helperfunctions.cpp']]],
  ['iscontained',['isContained',['../classEdgeLoop.html#acae6f647805e3f043325f047208556c8',1,'EdgeLoop']]],
  ['issubset',['isSubset',['../helperfunctions_8cpp.html#ab52930079ad22c64677a4bcafd8728c7',1,'isSubset(vector&lt; int &gt; &amp;a, vector&lt; int &gt; &amp;b):&#160;helperfunctions.cpp'],['../helperfunctions_8h.html#ab52930079ad22c64677a4bcafd8728c7',1,'isSubset(vector&lt; int &gt; &amp;a, vector&lt; int &gt; &amp;b):&#160;helperfunctions.cpp']]]
];
