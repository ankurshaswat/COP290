var searchData=
[
  ['get_5fedges3d',['get_edges3D',['../objLoader_8h.html#a6e505fb672d9a42fb27028c8340e2611',1,'get_edges3D(std::vector&lt; Vertice &gt; &amp;out_vertices, std::vector&lt; std::vector&lt; unsigned int &gt; &gt; &amp;faces_vertices, std::set&lt; Edge &gt; &amp;edgeSet):&#160;objLoader.cpp'],['../objLoader_8cpp.html#a1d2e4768c65bd1c911d9810c0d72e227',1,'get_edges3D(std::vector&lt; Vertice &gt; &amp;vertices3D, std::vector&lt; std::vector&lt; unsigned int &gt; &gt; &amp;faces_vertices, std::set&lt; Edge &gt; &amp;edgeSet):&#160;objLoader.cpp']]],
  ['get_5fintersection',['get_intersection',['../helperfunctions_8cpp.html#aeeffe6b314e92051412034d7e06b03d6',1,'get_intersection(Edge a, Edge b):&#160;helperfunctions.cpp'],['../helperfunctions_8h.html#aeeffe6b314e92051412034d7e06b03d6',1,'get_intersection(Edge a, Edge b):&#160;helperfunctions.cpp']]],
  ['get_5fvertex_5finf',['get_vertex_inf',['../hiddenLines_8cpp.html#aba67ff1d3d9b1af057a7743947d8a716',1,'hiddenLines.cpp']]],
  ['getaxes',['getAxes',['../classFig3D.html#a4fbcfab626ef2fe938bc53dec4c0543a',1,'Fig3D']]],
  ['getedgeloops',['getEdgeLoops',['../reconstMethods_8h.html#aed7e2db16ce5e7210f9f80b20a8af52f',1,'getEdgeLoops(vector&lt; Edge &gt; &amp;edges, vector&lt; int &gt; coplanarIndices):&#160;reconstMethods.cpp'],['../reconstMethods_8cpp.html#aed7e2db16ce5e7210f9f80b20a8af52f',1,'getEdgeLoops(vector&lt; Edge &gt; &amp;edges, vector&lt; int &gt; coplanarIndices):&#160;reconstMethods.cpp']]],
  ['getprojections',['getProjections',['../classFig3D.html#af1000067e4e230b41059896c8cacd4e1',1,'Fig3D']]],
  ['gettransformation',['getTransformation',['../classWireFrame.html#a2cbc8d66f5c958499d5ffa3654988d5e',1,'WireFrame::getTransformation()'],['../classFig3D.html#a25a3607c2735064d0bc0081b271ea224',1,'Fig3D::getTransformation()']]]
];
