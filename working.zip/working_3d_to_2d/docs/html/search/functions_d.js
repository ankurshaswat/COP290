var searchData=
[
  ['update',['update',['../classMainWindow.html#a128f71880d4b9683149023fc46fcc9f8',1,'MainWindow']]]
];
