var searchData=
[
  ['b',['b',['../structPlane.html#a3d802fea10cfe6352e1792733d793b14',1,'Plane']]],
  ['back_5fproj',['back_proj',['../hiddenLines_8h.html#a5245c9f2d3321def89057b7d397d84e3',1,'back_proj(Vertice v, Edge e, int plane):&#160;hiddenLines.cpp'],['../hiddenLines_8cpp.html#a5245c9f2d3321def89057b7d397d84e3',1,'back_proj(Vertice v, Edge e, int plane):&#160;hiddenLines.cpp']]],
  ['basiccomponents_2eh',['basicComponents.h',['../basicComponents_8h.html',1,'']]]
];
