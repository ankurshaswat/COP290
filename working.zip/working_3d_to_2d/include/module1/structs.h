/** Custom data structures needed in reconstruction */
#ifndef STRUCTS_H
#define STRUCTS_H


class partialOrder
{
/** A partially ordered relation (needed in face reconstruction)*/
};

#endif
